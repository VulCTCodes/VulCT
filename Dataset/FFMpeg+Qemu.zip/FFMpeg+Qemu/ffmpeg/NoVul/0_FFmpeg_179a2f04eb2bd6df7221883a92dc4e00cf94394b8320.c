void checkasm_check_vf_threshold(void)
{
    check_threshold_8();
    report("threshold8");
}
