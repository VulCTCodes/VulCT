static void uninit(struct vf_instance *vf)
{
    free(vf->priv);
}
