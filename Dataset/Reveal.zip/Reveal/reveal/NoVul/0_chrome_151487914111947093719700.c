unsigned min_heap_size ( min_heap_t * s )
{
    return s -> n ;
}