hb_face_t * hb_face_get_empty ( void )
{
    return const_cast < hb_face_t * > ( & _hb_face_nil ) ;
}