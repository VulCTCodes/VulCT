static void version ( )
{
    printf ( "icucal version %s (ICU version %s), created by Stephen F. Booth.\n" , CAL_VERSION , U_ICU_VERSION ) ;
    puts ( U_COPYRIGHT_STRING ) ;
}