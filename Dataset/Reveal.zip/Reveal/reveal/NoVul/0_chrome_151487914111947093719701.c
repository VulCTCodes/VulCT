void min_heap_elem_init ( struct event * e )
{
    e -> min_heap_idx = - 1 ;
}