unsigned int hb_face_get_glyph_count ( hb_face_t * face )
{
    return face -> get_num_glyphs ( ) ;
}