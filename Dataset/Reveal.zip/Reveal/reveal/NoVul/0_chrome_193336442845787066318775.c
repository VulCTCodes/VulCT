int main ( int argc ATTRIBUTE_UNUSED , char * * argv ATTRIBUTE_UNUSED )
{
    printf ( "%s : RelaxNG support not compiled in\n" , argv [ 0 ] ) ;
    return ( 0 ) ;
}