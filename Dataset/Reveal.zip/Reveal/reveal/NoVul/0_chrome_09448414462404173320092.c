int main ( int argc , char * * argv )
{
    BlinkMediaTestSuite test_suite ( argc , argv ) ;
return base : :
           LaunchUnitTests ( argc , argv , base : : Bind ( & BlinkMediaTestSuite : : Run , base : : Unretained ( & test_suite ) ) ) ;
}