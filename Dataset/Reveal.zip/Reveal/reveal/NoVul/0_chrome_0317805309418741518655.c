xmlChar * xsltAttrTemplateValueProcess ( xsltTransformContextPtr ctxt , const xmlChar * str )
{
    return ( xsltAttrTemplateValueProcessNode ( ctxt , str , NULL ) ) ;
}