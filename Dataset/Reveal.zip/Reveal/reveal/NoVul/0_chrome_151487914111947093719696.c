void min_heap_ctor ( min_heap_t * s )
{
    s -> p = 0 ;
    s -> n = 0 ;
    s -> a = 0 ;
}