IN_PROC_BROWSER_TEST_F ( SiteDetailsBrowserTest , MAYBE_IsolateExtensions )
{
    scoped_refptr < TestMemoryDetails > details = new TestMemoryDetails ( ) ;
    details -> StartFetchAndWait ( ) ;
    EXPECT_THAT ( details -> uma ( ) -> GetAllSamples ( "SiteIsolation.CurrentRendererProcessCount" ) , HasOneSample ( GetRenderProcessCount ( ) ) ) ;
    EXPECT_THAT ( details -> uma ( ) -> GetAllSamples ( "SiteIsolation.IsolateNothingProcessCountEstimate" ) , HasOneSample ( 1 ) ) ;
    EXPECT_THAT ( details -> uma ( ) -> GetAllSamples ( "SiteIsolation.IsolateExtensionsProcessCountEstimate" ) , HasOneSample ( 1 ) ) ;
    EXPECT_THAT ( details -> uma ( ) -> GetAllSamples ( "SiteIsolation.IsolateExtensionsProcessCountLowerBound" ) , HasOneSample ( 1 ) ) ;
    EXPECT_THAT ( details -> uma ( ) -> GetAllSamples ( "SiteIsolation.IsolateExtensionsProcessCountNoLimit" ) , HasOneSample ( 1 ) ) ;
    EXPECT_THAT ( GetRenderProcessCount ( ) , 1 ) ;
    EXPECT_EQ ( 0 , details -> GetOutOfProcessIframeCount ( ) ) ;
    const Extension * extension1 = CreateExtension ( "Extension One" , true ) ;
    const Extension * extension2 = CreateExtension ( "Extension Two" , false ) ;
    GURL tab1_url = embedded_test_server ( ) -> GetURL ( "a.com" , "/cross_site_iframe_factory.html?a(b,c)" ) ;
ui_test_utils : :
    NavigateToURL ( browser ( ) , tab1_url ) ;
    WebContents * tab1 = browser ( ) -> tab_strip_model ( ) -> GetWebContentsAt ( 0 ) ;
    GURL tab2_url = embedded_test_server ( ) -> GetURL ( "a.com" , "/cross_site_iframe_factory.html?a(d,e)" ) ;
    AddTabAtIndex ( 1 , tab2_url , ui : : PAGE_TRANSITION_TYPED ) ;
    WebContents * tab2 = browser ( ) -> tab_strip_model ( ) -> GetWebContentsAt ( 1 ) ;
    details = new TestMemoryDetails ( ) ;
    details -> StartFetchAndWait ( ) ;
    EXPECT_THAT ( details -> uma ( ) -> GetAllSamples ( "SiteIsolation.CurrentRendererProcessCount" ) , HasOneSample ( GetRenderProcessCount ( ) ) ) ;
    EXPECT_THAT ( details -> uma ( ) -> GetAllSamples ( "SiteIsolation.IsolateNothingProcessCountEstimate" ) , HasOneSample ( 3 ) ) ;
    EXPECT_THAT ( details -> uma ( ) -> GetAllSamples ( "SiteIsolation.IsolateExtensionsProcessCountEstimate" ) , HasOneSample ( 3 ) ) ;
    EXPECT_THAT ( details -> uma ( ) -> GetAllSamples ( "SiteIsolation.IsolateExtensionsProcessCountLowerBound" ) , HasOneSample ( 2 ) ) ;
    EXPECT_THAT ( details -> uma ( ) -> GetAllSamples ( "SiteIsolation.IsolateExtensionsProcessCountNoLimit" ) , HasOneSample ( 3 ) ) ;
    EXPECT_THAT ( GetRenderProcessCount ( ) , DependingOnPolicy ( 3 , 3 , 7 ) ) ;
    EXPECT_THAT ( details -> GetOutOfProcessIframeCount ( ) , DependingOnPolicy ( 0 , 0 , 4 ) ) ;
content : :
    NavigateIframeToURL ( tab1 , "child-0" , extension1 -> GetResourceURL ( "/blank_iframe.html" ) ) ;
    details = new TestMemoryDetails ( ) ;
    details -> StartFetchAndWait ( ) ;
    EXPECT_THAT ( details -> uma ( ) -> GetAllSamples ( "SiteIsolation.CurrentRendererProcessCount" ) , HasOneSample ( GetRenderProcessCount ( ) ) ) ;
    EXPECT_THAT ( details -> uma ( ) -> GetAllSamples ( "SiteIsolation.IsolateNothingProcessCountEstimate" ) , HasOneSample ( 3 ) ) ;
    EXPECT_THAT ( details -> uma ( ) -> GetAllSamples ( "SiteIsolation.IsolateExtensionsProcessCountEstimate" ) , HasOneSample ( 3 ) ) ;
    EXPECT_THAT ( details -> uma ( ) -> GetAllSamples ( "SiteIsolation.IsolateExtensionsProcessCountLowerBound" ) , HasOneSample ( 2 ) ) ;
    EXPECT_THAT ( details -> uma ( ) -> GetAllSamples ( "SiteIsolation.IsolateExtensionsProcessCountNoLimit" ) , HasOneSample ( 3 ) ) ;
    EXPECT_THAT ( GetRenderProcessCount ( ) , DependingOnPolicy ( 3 , 3 , 6 ) ) ;
    EXPECT_THAT ( details -> GetOutOfProcessIframeCount ( ) , DependingOnPolicy ( 0 , 1 , 4 ) ) ;
content : :
    NavigateIframeToURL ( tab2 , "child-0" , extension1 -> GetResourceURL ( "/blank_iframe.html" ) ) ;
    details = new TestMemoryDetails ( ) ;
    details -> StartFetchAndWait ( ) ;
    EXPECT_THAT ( details -> uma ( ) -> GetAllSamples ( "SiteIsolation.CurrentRendererProcessCount" ) , HasOneSample ( GetRenderProcessCount ( ) ) ) ;
    EXPECT_THAT ( details -> uma ( ) -> GetAllSamples ( "SiteIsolation.IsolateNothingProcessCountEstimate" ) , HasOneSample ( 3 ) ) ;
    EXPECT_THAT ( details -> uma ( ) -> GetAllSamples ( "SiteIsolation.IsolateExtensionsProcessCountEstimate" ) , HasOneSample ( 3 ) ) ;
    EXPECT_THAT ( details -> uma ( ) -> GetAllSamples ( "SiteIsolation.IsolateExtensionsProcessCountLowerBound" ) , HasOneSample ( 2 ) ) ;
    EXPECT_THAT ( details -> uma ( ) -> GetAllSamples ( "SiteIsolation.IsolateExtensionsProcessCountNoLimit" ) , HasOneSample ( 3 ) ) ;
    EXPECT_THAT ( GetRenderProcessCount ( ) , DependingOnPolicy ( 3 , 3 , 5 ) ) ;
    EXPECT_THAT ( details -> GetOutOfProcessIframeCount ( ) , DependingOnPolicy ( 0 , 2 , 4 ) ) ;
content : :
    NavigateIframeToURL ( tab1 , "child-1" , extension2 -> GetResourceURL ( "/blank_iframe.html" ) ) ;
    details = new TestMemoryDetails ( ) ;
    details -> StartFetchAndWait ( ) ;
    EXPECT_THAT ( details -> uma ( ) -> GetAllSamples ( "SiteIsolation.CurrentRendererProcessCount" ) , HasOneSample ( GetRenderProcessCount ( ) ) ) ;
    EXPECT_THAT ( details -> uma ( ) -> GetAllSamples ( "SiteIsolation.IsolateNothingProcessCountEstimate" ) , HasOneSample ( 3 ) ) ;
    EXPECT_THAT ( details -> uma ( ) -> GetAllSamples ( "SiteIsolation.IsolateExtensionsProcessCountEstimate" ) , HasOneSample ( 4 ) ) ;
    EXPECT_THAT ( details -> uma ( ) -> GetAllSamples ( "SiteIsolation.IsolateExtensionsProcessCountLowerBound" ) , HasOneSample ( 3 ) ) ;
    EXPECT_THAT ( details -> uma ( ) -> GetAllSamples ( "SiteIsolation.IsolateExtensionsProcessCountNoLimit" ) , HasOneSample ( 4 ) ) ;
    EXPECT_THAT ( GetRenderProcessCount ( ) , DependingOnPolicy ( 3 , 4 , 5 ) ) ;
    EXPECT_THAT ( details -> GetOutOfProcessIframeCount ( ) , DependingOnPolicy ( 0 , 3 , 4 ) ) ;
content : :
    NavigateIframeToURL ( tab2 , "child-1" , extension2 -> GetResourceURL ( "/blank_iframe.html" ) ) ;
    details = new TestMemoryDetails ( ) ;
    details -> StartFetchAndWait ( ) ;
    EXPECT_THAT ( details -> uma ( ) -> GetAllSamples ( "SiteIsolation.CurrentRendererProcessCount" ) , HasOneSample ( GetRenderProcessCount ( ) ) ) ;
    EXPECT_THAT ( details -> uma ( ) -> GetAllSamples ( "SiteIsolation.IsolateNothingProcessCountEstimate" ) , HasOneSample ( 3 ) ) ;
    EXPECT_THAT ( details -> uma ( ) -> GetAllSamples ( "SiteIsolation.IsolateExtensionsProcessCountEstimate" ) , HasOneSample ( 4 ) ) ;
    EXPECT_THAT ( details -> uma ( ) -> GetAllSamples ( "SiteIsolation.IsolateExtensionsProcessCountLowerBound" ) , HasOneSample ( 3 ) ) ;
    EXPECT_THAT ( details -> uma ( ) -> GetAllSamples ( "SiteIsolation.IsolateExtensionsProcessCountNoLimit" ) , HasOneSample ( 4 ) ) ;
    EXPECT_THAT ( GetRenderProcessCount ( ) , DependingOnPolicy ( 3 , 4 , 4 ) ) ;
    EXPECT_THAT ( details -> GetOutOfProcessIframeCount ( ) , DependingOnPolicy ( 0 , 4 , 4 ) ) ;
    const Extension * extension3 = CreateExtension ( "Extension Three" , false ) ;
ui_test_utils : :
    NavigateToURL ( browser ( ) , extension3 -> GetResourceURL ( "blank_iframe.html" ) ) ;
    details = new TestMemoryDetails ( ) ;
    details -> StartFetchAndWait ( ) ;
    EXPECT_THAT ( details -> uma ( ) -> GetAllSamples ( "SiteIsolation.CurrentRendererProcessCount" ) , HasOneSample ( GetRenderProcessCount ( ) ) ) ;
    EXPECT_THAT ( details -> uma ( ) -> GetAllSamples ( "SiteIsolation.IsolateNothingProcessCountEstimate" ) , HasOneSample ( 3 ) ) ;
    EXPECT_THAT ( details -> uma ( ) -> GetAllSamples ( "SiteIsolation.IsolateExtensionsProcessCountEstimate" ) , HasOneSample ( 4 ) ) ;
    EXPECT_THAT ( details -> uma ( ) -> GetAllSamples ( "SiteIsolation.IsolateExtensionsProcessCountLowerBound" ) , HasOneSample ( 4 ) ) ;
    EXPECT_THAT ( details -> uma ( ) -> GetAllSamples ( "SiteIsolation.IsolateExtensionsProcessCountNoLimit" ) , HasOneSample ( 4 ) ) ;
    EXPECT_THAT ( GetRenderProcessCount ( ) , DependingOnPolicy ( 3 , 4 , 4 ) ) ;
    EXPECT_THAT ( details -> GetOutOfProcessIframeCount ( ) , DependingOnPolicy ( 0 , 2 , 2 ) ) ;
ui_test_utils : :
    NavigateToURL ( browser ( ) , extension3 -> GetResourceURL ( "http_iframe.html" ) ) ;
    details = new TestMemoryDetails ( ) ;
    details -> StartFetchAndWait ( ) ;
    EXPECT_THAT ( details -> uma ( ) -> GetAllSamples ( "SiteIsolation.CurrentRendererProcessCount" ) , HasOneSample ( GetRenderProcessCount ( ) ) ) ;
    EXPECT_THAT ( details -> uma ( ) -> GetAllSamples ( "SiteIsolation.IsolateNothingProcessCountEstimate" ) , HasOneSample ( 3 ) ) ;
    EXPECT_THAT ( details -> uma ( ) -> GetAllSamples ( "SiteIsolation.IsolateExtensionsProcessCountEstimate" ) , HasOneSample ( 5 ) ) ;
    EXPECT_THAT ( details -> uma ( ) -> GetAllSamples ( "SiteIsolation.IsolateExtensionsProcessCountLowerBound" ) , HasOneSample ( 4 ) ) ;
    EXPECT_THAT ( details -> uma ( ) -> GetAllSamples ( "SiteIsolation.IsolateExtensionsProcessCountNoLimit" ) , HasOneSample ( 5 ) ) ;
    EXPECT_THAT ( GetRenderProcessCount ( ) , DependingOnPolicy ( 3 , 5 , 5 ) ) ;
    EXPECT_THAT ( details -> GetOutOfProcessIframeCount ( ) , DependingOnPolicy ( 0 , 3 , 3 ) ) ;
    browser ( ) -> tab_strip_model ( ) -> ActivateTabAt ( 0 , true ) ;
ui_test_utils : :
    NavigateToURL ( browser ( ) , extension3 -> GetResourceURL ( "blank_iframe.html" ) ) ;
    details = new TestMemoryDetails ( ) ;
    details -> StartFetchAndWait ( ) ;
    EXPECT_THAT ( details -> uma ( ) -> GetAllSamples ( "SiteIsolation.CurrentRendererProcessCount" ) , HasOneSample ( GetRenderProcessCount ( ) ) ) ;
    EXPECT_THAT ( details -> uma ( ) -> GetAllSamples ( "SiteIsolation.IsolateNothingProcessCountEstimate" ) , HasOneSample ( 2 ) ) ;
    EXPECT_THAT ( details -> uma ( ) -> GetAllSamples ( "SiteIsolation.IsolateExtensionsProcessCountEstimate" ) , HasOneSample ( 3 ) ) ;
    EXPECT_THAT ( details -> uma ( ) -> GetAllSamples ( "SiteIsolation.IsolateExtensionsProcessCountLowerBound" ) , HasOneSample ( 3 ) ) ;
    EXPECT_THAT ( details -> uma ( ) -> GetAllSamples ( "SiteIsolation.IsolateExtensionsProcessCountNoLimit" ) , HasOneSample ( 3 ) ) ;
    EXPECT_THAT ( GetRenderProcessCount ( ) , DependingOnPolicy ( 2 , 3 , 3 ) ) ;
    EXPECT_THAT ( details -> GetOutOfProcessIframeCount ( ) , DependingOnPolicy ( 0 , 1 , 1 ) ) ;
ui_test_utils : :
    NavigateToURL ( browser ( ) , extension3 -> GetResourceURL ( "http_iframe.html" ) ) ;
    details = new TestMemoryDetails ( ) ;
    details -> StartFetchAndWait ( ) ;
    EXPECT_THAT ( details -> uma ( ) -> GetAllSamples ( "SiteIsolation.CurrentRendererProcessCount" ) , HasOneSample ( GetRenderProcessCount ( ) ) ) ;
    EXPECT_THAT ( details -> uma ( ) -> GetAllSamples ( "SiteIsolation.IsolateNothingProcessCountEstimate" ) , HasOneSample ( 2 ) ) ;
    EXPECT_THAT ( details -> uma ( ) -> GetAllSamples ( "SiteIsolation.IsolateExtensionsProcessCountEstimate" ) , HasOneSample ( 4 ) ) ;
    EXPECT_THAT ( details -> uma ( ) -> GetAllSamples ( "SiteIsolation.IsolateExtensionsProcessCountLowerBound" ) , HasOneSample ( 3 ) ) ;
    EXPECT_THAT ( details -> uma ( ) -> GetAllSamples ( "SiteIsolation.IsolateExtensionsProcessCountNoLimit" ) , HasOneSample ( 4 ) ) ;
    EXPECT_THAT ( GetRenderProcessCount ( ) , DependingOnPolicy ( 2 , 4 , 3 ) ) ;
    EXPECT_THAT ( details -> GetOutOfProcessIframeCount ( ) , DependingOnPolicy ( 0 , 2 , 2 ) ) ;
}