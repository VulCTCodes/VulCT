unsigned int hb_face_get_index ( hb_face_t * face )
{
    return face -> index ;
}