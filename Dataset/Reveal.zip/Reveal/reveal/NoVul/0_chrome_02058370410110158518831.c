bool RegisterChromeDownloadDelegate ( JNIEnv * env )
{
    return RegisterNativesImpl ( env ) ;
}