static int unscaled_value ( int val , const struct scale_factors * sf )
{
    ( void ) sf ;
    return val ;
}