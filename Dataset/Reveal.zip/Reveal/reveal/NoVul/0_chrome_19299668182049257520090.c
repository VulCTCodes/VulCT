IN_PROC_BROWSER_TEST_F ( PnaclHeaderTest , TestHasPnaclHeader )
{
    RunLoadTest ( "acl/pnacl_request_header/pnacl_request_header.html" , 1 , 1 ) ;
}