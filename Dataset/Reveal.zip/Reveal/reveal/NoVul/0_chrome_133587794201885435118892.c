IN_PROC_BROWSER_TEST_F ( UnloadTest , BrowserCloseTwoSecondUnloadAlert )
{
    LoadUrlAndQuitBrowser ( TWO_SECOND_UNLOAD_ALERT_HTML , "twosecondunloadalert" ) ;
}