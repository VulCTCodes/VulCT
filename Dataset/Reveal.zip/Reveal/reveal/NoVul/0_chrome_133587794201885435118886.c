IN_PROC_BROWSER_TEST_F ( UnloadTest , BrowserCloseTwoSecondBeforeUnloadAlert )
{
    LoadUrlAndQuitBrowser ( TWO_SECOND_BEFORE_UNLOAD_ALERT_HTML , "twosecondbeforeunloadalert" ) ;
}