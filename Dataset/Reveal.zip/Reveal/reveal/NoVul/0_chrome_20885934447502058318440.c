static void free_months ( UChar * months [ ] )
{
    free_symbols ( months , MONTH_COUNT - 1 ) ;
}