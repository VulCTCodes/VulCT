static void free_days ( UChar * days [ ] )
{
    free_symbols ( days , DAY_COUNT ) ;
}