IN_PROC_BROWSER_TEST_F ( FastUnloadTest , DISABLED_ClosingLastTabFinishesUnload )
{
# if defined ( OS_WIN ) if ( base : : win : : GetVersion ( ) >= base : : win : : VERSION_WIN7 ) return ;
# endif NavigateToPage ( "no_listeners" ) ;
    EXPECT_EQ ( "unloaded=ohyeah" , GetCookies ( "no_listeners" ) ) ;
}