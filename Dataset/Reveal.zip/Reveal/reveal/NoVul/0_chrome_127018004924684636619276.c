unsigned int hb_face_get_upem ( hb_face_t * face )
{
    return face -> get_upem ( ) ;
}