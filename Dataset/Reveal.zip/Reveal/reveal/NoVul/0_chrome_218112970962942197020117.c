IN_PROC_BROWSER_TEST_F ( DownloadNotificationTest , SimultaneousIncognitoAndNormalDownloads )
{
    PrepareIncognitoBrowser ( ) ;
    GURL url_incognito ( net : : URLRequestSlowDownloadJob : : kUnknownSizeUrl ) ;
    GURL url_normal ( net : : URLRequestSlowDownloadJob : : kKnownSizeUrl ) ;
ui_test_utils : :
    NavigateToURL ( incognito_browser ( ) , url_incognito ) ;
    WaitForDownloadNotification ( incognito_browser ( ) ) ;
    auto incognito_notifications = incognito_display_service_ -> GetDisplayedNotificationsForType ( NotificationHandler : : Type : : TRANSIENT ) ;
    ASSERT_EQ ( 1u , incognito_notifications . size ( ) ) ;
std : :
    string notification_id1 = incognito_notifications [ 0 ] . id ( ) ;
    EXPECT_FALSE ( notification_id1 . empty ( ) ) ;
std : :
vector < download : : DownloadItem * > downloads ;
    GetDownloadManager ( browser ( ) ) -> GetAllDownloads ( & downloads ) ;
    EXPECT_EQ ( 0u , downloads . size ( ) ) ;
    downloads . clear ( ) ;
    GetDownloadManager ( incognito_browser ( ) ) -> GetAllDownloads ( & downloads ) ;
    EXPECT_EQ ( 1u , downloads . size ( ) ) ;
download : :
    DownloadItem * download_incognito = downloads [ 0 ] ;
ui_test_utils : :
    NavigateToURL ( browser ( ) , url_normal ) ;
    WaitForDownloadNotification ( ) ;
    auto normal_notifications = GetDownloadNotifications ( ) ;
    ASSERT_EQ ( 1u , normal_notifications . size ( ) ) ;
std : :
    string notification_id2 = normal_notifications [ 0 ] . id ( ) ;
    EXPECT_FALSE ( notification_id2 . empty ( ) ) ;
    downloads . clear ( ) ;
    GetDownloadManager ( browser ( ) ) -> GetAllDownloads ( & downloads ) ;
download : :
    DownloadItem * download_normal = downloads [ 0 ] ;
    EXPECT_EQ ( 1u , downloads . size ( ) ) ;
    EXPECT_NE ( download_normal , download_incognito ) ;
    downloads . clear ( ) ;
    GetDownloadManager ( incognito_browser ( ) ) -> GetAllDownloads ( & downloads ) ;
    EXPECT_EQ ( 1u , downloads . size ( ) ) ;
    EXPECT_EQ ( download_incognito , downloads [ 0 ] ) ;
    auto incognito_notification = incognito_display_service_ -> GetNotification ( notification_id1 ) ;
    ASSERT_TRUE ( incognito_notification ) ;
    EXPECT_EQ ( message_center : : NOTIFICATION_TYPE_PROGRESS , incognito_notification -> type ( ) ) ;
    EXPECT_EQ ( - 1 , incognito_notification -> progress ( ) ) ;
    auto normal_notification = display_service_ -> GetNotification ( notification_id2 ) ;
    ASSERT_TRUE ( normal_notification ) ;
    EXPECT_EQ ( message_center : : NOTIFICATION_TYPE_PROGRESS , normal_notification -> type ( ) ) ;
    EXPECT_LE ( 0 , normal_notification -> progress ( ) ) ;
    EXPECT_TRUE ( content : : DownloadItemUtils : : GetBrowserContext ( download_incognito ) -> IsOffTheRecord ( ) ) ;
    EXPECT_FALSE ( content : : DownloadItemUtils : : GetBrowserContext ( download_normal ) -> IsOffTheRecord ( ) ) ;
    CompleteTheDownload ( ) ;
    incognito_notification = incognito_display_service_ -> GetNotification ( notification_id1 ) ;
    EXPECT_EQ ( message_center : : NOTIFICATION_TYPE_BASE_FORMAT , incognito_notification -> type ( ) ) ;
    normal_notification = display_service_ -> GetNotification ( notification_id2 ) ;
    EXPECT_EQ ( message_center : : NOTIFICATION_TYPE_BASE_FORMAT , normal_notification -> type ( ) ) ;
chrome : :
    CloseWindow ( incognito_browser ( ) ) ;
}