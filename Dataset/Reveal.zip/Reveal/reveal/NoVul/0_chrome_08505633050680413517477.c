static int delta_thresh ( BLOCK_SIZE bs , int increase_denoising )
{
    ( void ) bs ;
    ( void ) increase_denoising ;
    return 4 ;
}