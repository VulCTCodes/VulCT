static int noise_motion_thresh ( BLOCK_SIZE bs , int increase_denoising )
{
    ( void ) bs ;
    ( void ) increase_denoising ;
    return 25 * 25 ;
}