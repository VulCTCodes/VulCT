hb_bool_t hb_face_is_immutable ( hb_face_t * face )
{
    return face -> immutable ;
}