IN_PROC_BROWSER_TEST_F ( MultiProfileDownloadNotificationTest , PRE_DownloadMultipleFiles )
{
    AddAllUsers ( ) ;
}