xmlNodePtr * xsltTemplateProcess ( xsltTransformContextPtr ctxt ATTRIBUTE_UNUSED , xmlNodePtr node )
{
    if ( node == NULL )
    {
        return ( NULL ) ;
    }
    return ( 0 ) ;
}