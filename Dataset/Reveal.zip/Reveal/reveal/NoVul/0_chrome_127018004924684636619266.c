hb_blob_t * hb_face_reference_table ( hb_face_t * face , hb_tag_t tag )
{
    return face -> reference_table ( tag ) ;
}