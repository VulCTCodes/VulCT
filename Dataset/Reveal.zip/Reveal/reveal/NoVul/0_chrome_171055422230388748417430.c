void vp9_idct8x8_64_add_sse2 ( const int16_t * input , uint8_t * dest , int stride )
{
    const __m128i zero = _mm_setzero_si128 ( ) ;
    const __m128i rounding = _mm_set1_epi32 ( DCT_CONST_ROUNDING ) ;
    const __m128i final_rounding = _mm_set1_epi16 ( 1 << 4 ) ;
    const __m128i stg1_0 = pair_set_epi16 ( cospi_28_64 , - cospi_4_64 ) ;
    const __m128i stg1_1 = pair_set_epi16 ( cospi_4_64 , cospi_28_64 ) ;
    const __m128i stg1_2 = pair_set_epi16 ( - cospi_20_64 , cospi_12_64 ) ;
    const __m128i stg1_3 = pair_set_epi16 ( cospi_12_64 , cospi_20_64 ) ;
    const __m128i stg2_0 = pair_set_epi16 ( cospi_16_64 , cospi_16_64 ) ;
    const __m128i stg2_1 = pair_set_epi16 ( cospi_16_64 , - cospi_16_64 ) ;
    const __m128i stg2_2 = pair_set_epi16 ( cospi_24_64 , - cospi_8_64 ) ;
    const __m128i stg2_3 = pair_set_epi16 ( cospi_8_64 , cospi_24_64 ) ;
    __m128i in0 , in1 , in2 , in3 , in4 , in5 , in6 , in7 ;
    __m128i stp1_0 , stp1_1 , stp1_2 , stp1_3 , stp1_4 , stp1_5 , stp1_6 , stp1_7 ;
    __m128i stp2_0 , stp2_1 , stp2_2 , stp2_3 , stp2_4 , stp2_5 , stp2_6 , stp2_7 ;
    __m128i tmp0 , tmp1 , tmp2 , tmp3 , tmp4 , tmp5 , tmp6 , tmp7 ;
    int i ;
    in0 = _mm_load_si128 ( ( const __m128i * ) input ) ;
    in1 = _mm_load_si128 ( ( const __m128i * ) ( input + 8 * 1 ) ) ;
    in2 = _mm_load_si128 ( ( const __m128i * ) ( input + 8 * 2 ) ) ;
    in3 = _mm_load_si128 ( ( const __m128i * ) ( input + 8 * 3 ) ) ;
    in4 = _mm_load_si128 ( ( const __m128i * ) ( input + 8 * 4 ) ) ;
    in5 = _mm_load_si128 ( ( const __m128i * ) ( input + 8 * 5 ) ) ;
    in6 = _mm_load_si128 ( ( const __m128i * ) ( input + 8 * 6 ) ) ;
    in7 = _mm_load_si128 ( ( const __m128i * ) ( input + 8 * 7 ) ) ;
    for ( i = 0 ;
            i < 2 ;
            i ++ )
    {
        TRANSPOSE_8X8 ( in0 , in1 , in2 , in3 , in4 , in5 , in6 , in7 , in0 , in1 , in2 , in3 , in4 , in5 , in6 , in7 ) ;
        IDCT8 ( in0 , in1 , in2 , in3 , in4 , in5 , in6 , in7 , in0 , in1 , in2 , in3 , in4 , in5 , in6 , in7 ) ;
    }
    in0 = _mm_adds_epi16 ( in0 , final_rounding ) ;
    in1 = _mm_adds_epi16 ( in1 , final_rounding ) ;
    in2 = _mm_adds_epi16 ( in2 , final_rounding ) ;
    in3 = _mm_adds_epi16 ( in3 , final_rounding ) ;
    in4 = _mm_adds_epi16 ( in4 , final_rounding ) ;
    in5 = _mm_adds_epi16 ( in5 , final_rounding ) ;
    in6 = _mm_adds_epi16 ( in6 , final_rounding ) ;
    in7 = _mm_adds_epi16 ( in7 , final_rounding ) ;
    in0 = _mm_srai_epi16 ( in0 , 5 ) ;
    in1 = _mm_srai_epi16 ( in1 , 5 ) ;
    in2 = _mm_srai_epi16 ( in2 , 5 ) ;
    in3 = _mm_srai_epi16 ( in3 , 5 ) ;
    in4 = _mm_srai_epi16 ( in4 , 5 ) ;
    in5 = _mm_srai_epi16 ( in5 , 5 ) ;
    in6 = _mm_srai_epi16 ( in6 , 5 ) ;
    in7 = _mm_srai_epi16 ( in7 , 5 ) ;
    RECON_AND_STORE ( dest , in0 ) ;
    RECON_AND_STORE ( dest , in1 ) ;
    RECON_AND_STORE ( dest , in2 ) ;
    RECON_AND_STORE ( dest , in3 ) ;
    RECON_AND_STORE ( dest , in4 ) ;
    RECON_AND_STORE ( dest , in5 ) ;
    RECON_AND_STORE ( dest , in6 ) ;
    RECON_AND_STORE ( dest , in7 ) ;
}