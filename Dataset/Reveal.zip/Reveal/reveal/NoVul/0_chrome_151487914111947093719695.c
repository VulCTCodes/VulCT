int min_heap_empty ( min_heap_t * s )
{
    return 0u == s -> n ;
}