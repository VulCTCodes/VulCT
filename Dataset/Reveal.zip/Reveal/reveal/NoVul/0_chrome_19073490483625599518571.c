int main ( )
{
    fprintf ( stderr , "libxml was not compiled with thread or catalog support\n" ) ;
    return ( 0 ) ;
}